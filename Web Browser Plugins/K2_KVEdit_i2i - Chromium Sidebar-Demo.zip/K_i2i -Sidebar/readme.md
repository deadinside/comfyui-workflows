Klein KV Edit — Chrome/Edge Extension
A lightweight right‑click → edit workflow for sending any image on the web directly into your Klein KV / Flux2 KV ComfyUI workflow.
Designed for fast iteration, prompt‑driven edits, and LoRA‑based style control — without clutter or unnecessary settings.

Features
Right‑click any image → Send to Klein KV Edit  
Instantly uploads the image to your ComfyUI server and opens the sidebar.

Sidebar editing panel

Live image preview

Prompt input

LoRA dropdown (auto‑scanned from your ComfyUI models folder)

Random seed support

Built‑in Prompt Builder with tabs, editing mode, and reusable fragments

Insert + Clear prompt controls

One‑click Generate

Minimal configuration  
Klein KV workflows perform best with fixed steps and CFG, so the extension keeps the UI clean and focused on prompts and LoRAs.

Automatic LoRA bypass  
If “None” is selected, the extension rewires the workflow to skip the LoRA node entirely.

Full Flux2 KV workflow compatibility  
Uses your provided KleinKVEdit_i2i_Plugin.json workflow and injects:

Uploaded image filename

Prompt

LoRA (or bypass)

Random seed

Requirements
ComfyUI running locally  
Default: http://127.0.0.1:8188  
(Configurable in extension Options)

Chrome or Microsoft Edge  
(Uses the MV3 sidePanel API)

Installation (Developer Mode)
Clone or download this repository

Open chrome://extensions

Enable Developer Mode

Click Load unpacked

Select the extension folder

Open the Options page and set your ComfyUI URL if needed

Usage
Right‑click any image on the web

Choose Send to Klein KV Edit

The sidebar opens automatically

Enter your prompt

Select a LoRA (or leave as None)

Click Generate

Output opens in a new tab

How It Works
Background Script
Fetches the clicked image

Uploads it to ComfyUI (/upload/image)

Stores the filename + preview URL

Opens the sidebar immediately (required by Chrome’s gesture rules)

Sidebar
Loads the stored image

Loads the workflow JSON

Injects prompt, LoRA, seed, and filename

Sends the workflow to /prompt

Polls /history/{id} until the SaveImage node returns output

LoRA Bypass Logic
If LoRA = None:

Code
139.model = ["126", 0]   // Base UNET
If LoRA selected:

Code
139.model = ["693", 0]   // LoRA wrapper
Folder Structure
Code
/manifest.json
/background.js
/KleinKVEdit_i2i_Plugin.json
/sidebar/
    sidebar.html
    sidebar.js
    sidebar.css
    comfy.js
    promptBuilder.js
    loraScanner.js
Known Limitations
Requires ComfyUI to be running before sending images

Only supports workflows using the same node IDs as the provided JSON

Sidebar must be pinned in Edge for persistent visibility

Roadmap
Output preview inside sidebar

History panel

Optional negative prompt support

Custom seed lock

Dark‑mode polish (in progress)

License
MIT License — free to modify, extend, and integrate into your own tools.
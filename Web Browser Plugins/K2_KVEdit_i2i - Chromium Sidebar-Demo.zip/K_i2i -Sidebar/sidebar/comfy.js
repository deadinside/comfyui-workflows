// comfy.js — Minimal KV‑Edit version

let COMFY_URL = "http://127.0.0.1:8188";

export function setComfyUrl(url) {
  COMFY_URL = url.replace(/\/+$/, "");
}

// Load the KV workflow JSON bundled with the extension
export async function loadWorkflow() {
  const res = await fetch(chrome.runtime.getURL("KleinKVEdit_i2i_Plugin.json"));
  return await res.json();
}

// Inject prompt, LoRA, uploaded filename, random seed
export function buildPromptPayload(workflow, ui) {
  const wf = structuredClone(workflow);

  // 1. Uploaded filename → LoadImage (76)
  if (wf["76"]?.class_type === "LoadImage") {
    wf["76"].inputs.image = ui.uploadedFilename;
  }

  // 2. Positive prompt → CLIPTextEncode (135)
  if (wf["135"]?.class_type === "CLIPTextEncode") {
    wf["135"].inputs.text = ui.prompt;
  }

  // 3. LoRA → LoraLoaderModelOnly (693) OR bypass
  if (wf["693"]?.class_type === "LoraLoaderModelOnly") {
    if (ui.loraName) {
      // LoRA enabled
      wf["693"].inputs.lora_name = ui.loraName;
      wf["693"].inputs.strength_model = 1;

      // Route model through LoRA
      wf["139"].inputs.model = ["693", 0];

    } else {
      // LoRA disabled → bypass
      wf["693"].inputs.lora_name = "";
      wf["693"].inputs.strength_model = 0;

      // Route model directly from UNETLoader (126)
      wf["139"].inputs.model = ["126", 0];
    }
  }

  // 4. Random seed → RandomNoise (125)
  if (wf["125"]?.class_type === "RandomNoise") {
    wf["125"].inputs.noise_seed = ui.seed || Math.floor(Math.random() * 1e15);
  }

  // No CFG, no negative prompt, no steps — workflow already fixed at 4 steps

  return { prompt: wf };
}

// Poll ComfyUI for results
export async function runComfyWorkflow(payload, onStatus) {
  const promptRes = await fetch(`${COMFY_URL}/prompt`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  }).then(r => r.json());

  const promptId = promptRes.prompt_id;
  onStatus?.("Processing…");

  while (true) {
    const history = await fetch(`${COMFY_URL}/history/${promptId}`)
      .then(r => r.json())
      .catch(() => null);

    if (!history) {
      await sleep(500);
      continue;
    }

    const entry = history[promptId];
    if (!entry) {
      await sleep(500);
      continue;
    }

    const outputs = entry.outputs;
    if (!outputs) {
      await sleep(500);
      continue;
    }

    // SaveImage node is 94
    const saveNode = outputs["94"];
    if (saveNode && saveNode.images && saveNode.images.length > 0) {
      const file = saveNode.images[0];
      const url = `${COMFY_URL}/view?filename=${file.filename}&type=output`;
      onStatus?.("Done");
      return { filename: file.filename, url };
    }

    await sleep(500);
  }
}

function sleep(ms) {
  return new Promise(res => setTimeout(res, ms));
}

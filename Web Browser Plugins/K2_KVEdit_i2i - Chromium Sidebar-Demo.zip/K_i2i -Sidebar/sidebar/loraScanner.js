window.loraScanner = {
  async load() {
    const select = document.getElementById('loraSelect');
    select.innerHTML = '<option value="">None</option>';

    // Load saved ComfyUI URL
    const { comfyUrl } = await new Promise(resolve => {
      chrome.storage.sync.get(['comfyUrl'], resolve);
    });

    if (!comfyUrl) {
      console.warn("KV Edit: No ComfyUI URL set.");
      return;
    }

    const base = comfyUrl.replace(/\/+$/, '');

    try {
      const res = await fetch(`${base}/models/loras`);
      if (!res.ok) throw new Error("HTTP " + res.status);

      const loras = await res.json(); // array of strings

      loras.forEach(name => {
        const opt = document.createElement('option');
        opt.value = name;
        opt.textContent = name;
        select.appendChild(opt);
      });

    } catch (e) {
      console.error("KV Edit: Failed to load LoRAs", e);
    }
  }
};

const MAX_ROWS = 20;

let state = {
  tabs: [],
  activeTabId: null,
  presets: {}
};

async function loadState() {
  return new Promise(resolve => {
    chrome.storage.sync.get(['promptBuilder'], data => {
      if (data.promptBuilder) {
        state = data.promptBuilder;
      }

      if (!state.tabs || state.tabs.length === 0) {
        const id = crypto.randomUUID();
        state = {
          tabs: [{ id, name: "Tab 1" }],
          activeTabId: id,
          presets: { [id]: [] }
        };
      }

      resolve();
    });
  });
}

function saveState() {
  chrome.storage.sync.set({ promptBuilder: state });
}

function renderTabs() {
  const tabsEl = document.getElementById("builderTabs");
  tabsEl.innerHTML = "";

  state.tabs.forEach(tab => {
    const btn = document.createElement("button");
    btn.className = "tab" + (tab.id === state.activeTabId ? " active" : "");
    btn.textContent = tab.name;

    btn.onclick = () => {
      state.activeTabId = tab.id;
      saveState();
      renderTabs();
      renderActiveTab();
    };

    tabsEl.appendChild(btn);
  });
}

function addTab() {
  const id = crypto.randomUUID();
  const index = state.tabs.length + 1;

  state.tabs.push({ id, name: `Tab ${index}` });
  state.presets[id] = [];
  state.activeTabId = id;

  saveState();
  renderTabs();
  renderActiveTab();
}

function renderActiveTab() {
  const content = document.getElementById("builderContent");
  content.innerHTML = "";

  const tabId = state.activeTabId;
  if (!tabId) return;

  const editMode = document.getElementById("editMode").checked;
  const presets = state.presets[tabId] || [];

  const grid = document.createElement("div");
  grid.className = "builder-grid";

  presets.forEach(preset => {
    const item = document.createElement("div");
    item.className = "builder-item";

    if (!editMode) {
      const label = document.createElement("label");
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = !!preset.enabled;

      cb.onchange = () => {
        preset.enabled = cb.checked;
        saveState();
        updatePreview();
      };

      const span = document.createElement("span");
      span.textContent = preset.nickname || "(unnamed)";

      label.appendChild(cb);
      label.appendChild(span);
      item.appendChild(label);
    } else {
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.placeholder = "Nickname";
      nameInput.value = preset.nickname || "";

      nameInput.onchange = () => {
        preset.nickname = nameInput.value;
        saveState();
        renderTabs();
      };

      const promptArea = document.createElement("textarea");
      promptArea.rows = 3;
      promptArea.placeholder = "Prompt (hidden)";
      promptArea.value = preset.prompt || "";

      promptArea.onchange = () => {
        preset.prompt = promptArea.value;
        saveState();
      };

      const del = document.createElement("button");
      del.textContent = "Delete";

      del.onclick = () => {
        state.presets[tabId] = presets.filter(p => p.id !== preset.id);
        saveState();
        renderActiveTab();
        updatePreview();
      };

      item.appendChild(nameInput);
      item.appendChild(promptArea);
      item.appendChild(del);
    }

    grid.appendChild(item);
  });

  content.appendChild(grid);

  if (editMode && presets.length < MAX_ROWS) {
    const add = document.createElement("button");
    add.textContent = "+ Add row";

    add.onclick = () => {
      state.presets[tabId].push({
        id: crypto.randomUUID(),
        nickname: "",
        prompt: "",
        enabled: false
      });

      saveState();
      renderActiveTab();
    };

    content.appendChild(add);
  }

  updatePreview();
}

function updatePreview() {
  const tabId = state.activeTabId;
  const presets = state.presets[tabId] || [];

  const combined = presets
    .filter(p => p.enabled && p.prompt)
    .map(p => p.prompt.trim())
    .join(", ");

  document.getElementById("builderPreview").value = combined;
}

function getCombinedPrompt() {
  const tabId = state.activeTabId;
  const presets = state.presets[tabId] || [];

  return presets
    .filter(p => p.enabled && p.prompt)
    .map(p => p.prompt.trim())
    .join(", ");
}

window.promptBuilder = {
  load: loadState,
  renderTabs,
  renderActiveTab,
  addTab,
  getCombined: getCombinedPrompt
};

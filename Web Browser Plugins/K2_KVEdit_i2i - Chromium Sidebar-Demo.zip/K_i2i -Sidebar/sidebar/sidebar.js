import { loadWorkflow, buildPromptPayload, runComfyWorkflow } from "./comfy.js";

document.addEventListener("DOMContentLoaded", async () => {
  const preview = document.getElementById("imagePreview");
  const noImage = document.getElementById("noImage");

  const promptEl = document.getElementById("prompt");
  const loraSelect = document.getElementById("loraSelect");

  const builderPanel = document.getElementById("builderPanel");
  const toggleBuilder = document.getElementById("toggleBuilder");

  const seedEl = document.getElementById("seed") || null; // optional
  const randomSeedBtn = document.getElementById("randomSeed") || null;

  let comfyBase = null;

  // Load ComfyUI URL
  chrome.storage.sync.get(["comfyUrl"], data => {
    comfyBase = (data.comfyUrl || "http://127.0.0.1:8188").replace(/\/+$/, "");
  });

  //Clear Prompt
  document.getElementById("clearPrompt").onclick = () => {
  promptEl.value = "";
  };

  // Load LoRAs
  await window.loraScanner.load();

  // Load Prompt Builder
  await window.promptBuilder.load();
  window.promptBuilder.renderTabs();
  window.promptBuilder.renderActiveTab();

  toggleBuilder.onclick = () => {
    const hidden = builderPanel.classList.toggle("hidden");
    toggleBuilder.textContent = hidden ? "Show Prompt Builder" : "Hide Prompt Builder";
  };

  document.getElementById("insertFromBuilder").onclick = () => {
    toggleBuilder.click();
  };

  document.getElementById("applyBuilder").onclick = () => {
    const combined = window.promptBuilder.getCombined();
    if (!combined) return;

    promptEl.value = promptEl.value
      ? `${promptEl.value.trim()}, ${combined}`
      : combined;
  };

  document.getElementById("editMode").onchange = () => {
    window.promptBuilder.renderActiveTab();
  };

  document.getElementById("addTab").onclick = () => {
    window.promptBuilder.addTab();
  };

  // Listen for new images from background.js
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.kvedit_input_image || changes.kvedit_source_preview) {
      loadImageFromStorage();
    }
  });

  // Initial load
  loadImageFromStorage();

  function loadImageFromStorage() {
    chrome.storage.local.get(
      ["kvedit_input_image", "kvedit_source_preview"],
      data => {
        const filename = data.kvedit_input_image;
        const previewUrl = data.kvedit_source_preview;

        if (!filename && !previewUrl) {
          preview.style.display = "none";
          noImage.style.display = "block";
          return;
        }

        if (previewUrl) preview.src = previewUrl;

        if (filename && comfyBase) {
          preview.src = `${comfyBase}/view?filename=${encodeURIComponent(filename)}&type=input`;
        }

        preview.style.display = "block";
        noImage.style.display = "none";
      }
    );
  }

  // Optional random seed button
  if (randomSeedBtn) {
    randomSeedBtn.onclick = () => {
      seedEl.value = Math.floor(Math.random() * 1e15);
    };
  }

  // Generate button
  document.getElementById("generate").onclick = async () => {
    const prompt = promptEl.value.trim();
    const loraName = loraSelect.value || "";
    const seed = seedEl ? (seedEl.value ? parseInt(seedEl.value) : Math.floor(Math.random() * 1e15)) : Math.floor(Math.random() * 1e15);

    if (!prompt) {
      alert("Please enter a prompt.");
      return;
    }

    chrome.storage.local.get(["kvedit_input_image"], async data => {
      const filename = data.kvedit_input_image;
      if (!filename) {
        alert("No image loaded. Right‑click an image first.");
        return;
      }

      try {
        const workflow = await loadWorkflow();
        const payload = buildPromptPayload(workflow, {
          uploadedFilename: filename,
          prompt,
          loraName,
          seed
        });

        const result = await runComfyWorkflow(payload, status => {
          console.log("Status:", status);
        });

        if (result?.url) {
          window.open(result.url, "_blank");
        }

      } catch (err) {
        console.error(err);
        alert("Failed to send to ComfyUI.");
      }
    });
  };

  // Options button
  document.getElementById("openOptions").onclick = () => {
    chrome.runtime.openOptionsPage();
  };
});
